<!DOCTYPE html> 
<html> 
	<head>
		<title>Search Engine in PHP</title> 
	</head>
	
<body bgcolor="gray">
	
	<form action="instest.php" method="post" enctype="multipart/form-data"> 
		
		<table bgcolor="orange" width="500" border="2" cellspacing="2" align="center">
			
			<tr>
				<td colspan="5" align="center"><h2>Inserting new website:</h2></td>
			</tr>
			<tr>
				<td align="right"><b>Site Title:</b></td>
				<td><input type="text" name="title" /></td>
			</tr>
			
			<tr>
				<td align="right"><b>Site Link:</b></td>
				<td><input type="text" name="link" /></td>
			</tr>
			
			<tr>
				<td align="right"><b>Site Keywords:</b></td>
				<td><input type="text" name="keywords" /></td>
			</tr>
			
			<tr>
				<td align="right"><b>Site Description:</b></td>
				<td><textarea cols="18" rows="8" name="desc"></textarea></td>
			</tr>
			
			
			
			<tr>
				<td align="center" colspan="5"><input type="submit" name="submit" value="Add Site Now"/></td>
			</tr>

		
		
		</table>
	
	
	</form>

</body>
</html>
<?php
 if(isset($_POST['submit']))
	{
       
		
		$title = $_POST['title'];
		$link = $_POST['link'];
		$keywords = $_POST['keywords'];
		$desc = $_POST['desc'];
	
		
		
		
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "article";

		
			$conn = new mysqli($servername, $username, $password,$dbname);
			
			if(!$conn)
			{
				die("connection failed:".mysqli_connect_error());
			}
		
			
			$sql="INSERT INTO sites(title , link , keywords , desc ) VALUES ('$title','$link','$keywords','$desc')";
			
			
			if (mysqli_query($conn,$sql))
			{
				echo "New record inserted";
			}
			//else
			//{
				//echo "Eror:";
			//}
			//mysqli_close($conn);
		
	}
	
?>





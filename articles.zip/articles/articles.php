<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Article Search Engine</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Law Firm Website Template" name="keywords">
        <meta content="Law Firm Website Template" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@1,600;1,700;1,800&family=Roboto:wght@400;500&display=swap" rel="stylesheet"> 
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
		
		
		 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="TemplateMo">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">

    <title>Article Search Engine</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-host-cloud.css">
    <link rel="stylesheet" href="assets/css/owl.css">
<!--

Host Cloud Template

https://templatemo.com/tm-541-host-cloud
    </head>

    <body>
        <div class="wrapper">
            <!-- Top Bar Start -->
           
            <!-- Top Bar End -->

            <!-- Nav Bar Start -->
            <div class="nav-bar">
                <div class="container-fluid">
                    <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                        <a href="#" class="navbar-brand">MENU</a>
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                            <div class="navbar-nav mr-auto">
                                <a href="index.php" class="nav-item nav-link">Home</a>
                                <a href="about.html" class="nav-item nav-link">About</a>
                                <a href="service.html" class="nav-item nav-link active">Crpc</a>
                                <a href="team.html" class="nav-item nav-link">Ipc</a>
                                <a href="portfolio.html" class="nav-item nav-link">Legal Acts</a>
                                <div class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Search</a>
                                    <div class="dropdown-menu">
                                        <a href="blog.html" class="dropdown-item">Blog Page</a>
                                        <a href="single.html" class="dropdown-item">Single Page</a>
                                    </div>
                                </div>
                                <a href="contact.html" class="nav-item nav-link">Contact</a>
                            </div>
                            
                        </div>
                    </nav>
                </div>
            </div>



<center><h1>ADD Code of Criminal Procedure</h1></center>



<center>
<br>
<form action="articles.php" method="post">
<table width="400" height="300" align="center">

<br><br>



<tr> 
<td>ID</td>
<td align="center"><input name="id" type="text" style="width:150px"></td>
</tr>

<tr> 
<td>SECTION</td>
<td align="center"><input name="section" type="text" style="width:150px"></td>
</tr>

<tr> 
<td>CRIME</td>
<td align="center"><input name="crime" type="text" style="width:150px"></td>
</tr>

<form enctype="multipart/form-data"
	action="<?php print $_SERVER['PHP_SELF']?>" method="post">
<p><input type="hidden" name="MAX_FILE_SIZE" value="200000" /> <input
	type="file" name="pdfFile" /><br />
<br />

</form>



<tr>
<td>&nbsp;</td>
<td align="center"><button type="submit" name="submit">SUBMIT</button></td></tr>

</table>
</form>

<?php
 if(isset($_POST['submit']))
	{
       
		
		$id = $_POST['id'];
		$section = $_POST['section'];
		$crime = $_POST['crime'];
		$content = $_POST['content'];
		
		
		
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "article";

		
			$conn = new mysqli($servername, $username, $password,$dbname);
			
			if(!$conn)
			{
				die("connection failed:".mysqli_connect_error());
			}
		
			
			$sql="INSERT INTO crpc(id , section , crime , content) VALUES ('$id','$section','$crime','$content')";
			
			
			if (mysqli_query($conn,$sql))
			{
				echo "New record inserted";
			}
			//else
			//{
				//echo "Eror:";
			//}
			//mysqli_close($conn);
		
	}
	
?>


</center>



  <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/accordions.js"></script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>






</body>
</html>

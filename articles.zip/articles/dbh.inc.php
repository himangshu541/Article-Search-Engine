<?php
    $dbServername = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "article";

    $conn=mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
?>


<?php
$dsn = 'mysql:host=localhost;dbname=article';
$username = 'root';
$password = '';
$options = [];
try {
$connection = new PDO($dsn, $username, $password, $options);
} catch(PDOException $e) {
}

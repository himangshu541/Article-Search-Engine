<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "article";


$conn = new mysqli($servername, $username, $password,$dbname);

if(!$conn)
{
    die("connection failed:".mysqli_connect_error());
}


$sql2 = "SELECT * FROM `notice`";
$result2s = $conn->query($sql2);
$result2 = mysqli_fetch_array($result2s);
$notice = $result2['text'];
$header1 = $result2['header'];

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Article Search Engine</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Law Firm Website Template" name="keywords">
        <meta content="Law Firm Website Template" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@1,600;1,700;1,800&family=Roboto:wght@400;500&display=swap" rel="stylesheet"> 
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
        <div class="wrapper">
            <!-- Top Bar Start -->
            <div class="top-bar">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="logo">
                                <a href="index.php">
                                    <h1>Article</h1>
                                    <!-- <img src="img/logo.jpg" alt="Logo"> -->
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <div class="top-bar-right">
                                <div class="text">
                                    <h2>10:00 - 17:00</h2>
                                    <p>Opening Hour Mon - Fri</p>
                                </div>
                                <div class="text">
                                    <h2>+911234567890</h2>
                                    <p>Call Us For Free Consultation</p>
                                </div>
                                <?php

                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "article";
                        $conn = new mysqli($servername, $username, $password,$dbname);
                        if(!$conn)
                        {
                            die("connection failed:".mysqli_connect_error());
                        }

                        $socialQuery = "SELECT * FROM `social` WHERE 1";
                        $socialResults = $conn->query($socialQuery);
                        $socialResult = mysqli_fetch_array($socialResults);
                        ?>

                        <div class="social">
                            <a href="<?=$socialResult['twitter']?>"><i class="fab fa-twitter"></i></a>
                            <a href="<?=$socialResult['facebook']?>"><i class="fab fa-facebook-f"></i></a>
                            <a href="<?=$socialResult['linkedin']?>"><i class="fab fa-linkedin-in"></i></a>
                            <a href="<?=$socialResult['insta']?>"><i class="fab fa-instagram"></i></a>
                        </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Top Bar End -->

            <!-- Nav Bar Start -->
            <div class="nav-bar">
                <div class="container-fluid">
                    <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                        <a href="#" class="navbar-brand">MENU</a>
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                            <div class="navbar-nav mr-auto">
                                <a href="index.php" class="nav-item nav-link active">Home</a>
                                <a href="aboutus.html" class="nav-item nav-link">About</a>
                                <a href="test.php" class="nav-item nav-link">Crpc</a>
                                <a href="searchxx.php" class="nav-item nav-link">Ipc</a>
                                <a href="lsearch.php" class="nav-item nav-link">Legal Acts</a>
								<a href="searchad.php" class="nav-item nav-link">Advance search</a>
								<a href="request.php" class="nav-item nav-link">Request</a>
                                
                                <a href="consult.php" class="nav-item nav-link">Contact</a>
                            </div>
                            <div class="ml-auto">
                                <a class="btn" href="login.php">ADMIN</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
            <!-- Nav Bar End -->
       


            <!-- Carousel Start -->
            <div id="carousel" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carousel" data-slide-to="0" class="active"></li>
                    <li data-target="#carousel" data-slide-to="1"></li>
                    <li data-target="#carousel" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="img/carousel-1.jpg" alt="Carousel Image">
                        <div class="carousel-caption">
                            <h1 class="animated fadeInLeft">Search Your Article</h1>
                            <p class="animated fadeInRight">Search any article which one you need</p>
                            <a class="btn animated fadeInUp" href="searchad.php">Search Here</a>
                        </div>
                    </div>

                    <div class="carousel-item">
                        <img src="img/carousel-2.jpg" alt="Carousel Image">
                        <div class="carousel-caption">
                            <h1 class="animated fadeInLeft">Any problem to find the Article</h1>
                            <p class="animated fadeInRight">Don't worry we are here just send your doubt</p>
                            <a class="btn animated fadeInUp" href="request.php">Send here</a>
                        </div>
                    </div>

                    <div class="carousel-item">
                        <img src="img/carousel-3.jpg" alt="Carousel Image">
                        <div class="carousel-caption">
                            <h1 class="animated fadeInLeft">We are here to help you</h1>
                            <p class="animated fadeInRight">Search your attorneys and contact them for free</p>
                            <a class="btn animated fadeInUp" href="consult.php">Get free consultation</a>
                        </div>
                    </div>
                </div>

                <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
            <!-- Carousel End -->
            
            
            <!-- Top Feature Start-->
            <div class="feature-top">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-md-3 col-sm-6">
                            <div class="feature-item">
                                <i class="far fa-check-circle"></i>
                                <h3>Legal</h3>
                                <p>Govt Approved</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="feature-item">
                                <i class="fa fa-user-tie"></i>
                                <h3>Attorneys</h3>
                                <p>Expert Attorneys</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="feature-item">
                                <i class="far fa-thumbs-up"></i>
                                <h3>Success</h3>
                                <p>Get Success</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="feature-item">
                                <i class="far fa-handshake"></i>
                                <h3>Support</h3>
                                <p>Quick Support</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Top Feature End-->
            
            
			     <?php
            if ($notice!="")
               echo '<marquee  direction="up" scrollamount="6">
<hr>
                <div class="alert alert-warning" role="alert"> 
                <h4 class="alert-heading">'.$header1.'!</h4>
                
                '.$notice.'
                 </div>
</marquee>';

            ?>
			
			
			
            <!-- About Start -->
            <div class="about">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-5 col-md-6">
                            <div class="about-img">
                                <img src="img/about.jpg" alt="Image">
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-6">
                            <div class="section-header">
                                <h2>Learn About Us</h2>
                            </div>
                            <div class="about-text">
                                <p>
                                    The web site Article Search Engine is a online  system that contains all the laws of Indian Constitution so that people can come and search for the law for respective crime. The laws are ...........
								</p>
                                
                                <a class="btn" href="aboutus.html">Learn More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- About End -->


            <!-- Service Start -->
            <div class="service">
                <div class="container">
                    <div class="section-header">
                        <h2>Learn About Different Laws</h2>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="service-item">
                                <div class="service-icon">
                                    <i class="fa fa-landmark"></i>
                                </div>
                                <h3>Civil Law</h3>
                                <p>
                                    Civil law is a legal system originating in mainland Europe and adopted in much of the world
                                </p>
                                <a class="btn" href="civil.html">Learn More</a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="service-item">
                                <div class="service-icon">
                                    <i class="fa fa-users"></i>
                                </div>
                                <h3>Family Law</h3>
                                <p>
                                    
								Family law is a practice area concerned with legal issues involving family relationships
                                </p>
                                <a class="btn" href="family.html">Learn More</a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="service-item">
                                <div class="service-icon">
                                    <i class="fa fa-hand-holding-usd"></i>
                                </div>
                                <h3>Business Law</h3>
                                <p>
                                    Business Law relates to the convention, agreement, governing the dealings between persons in commercial matters.
                                </p>
                                <a class="btn" href="business.html">Learn More</a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="service-item">
                                <div class="service-icon">
                                    <i class="fa fa-graduation-cap"></i>
                                </div>
                                <h3>Education Law</h3>
                                <p>
                                    Education law is the body of state and federal law that covers hole educationn system
                                </p>
                                <a class="btn" href="education.html">Learn More</a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="service-item">
                                <div class="service-icon">
                                    <i class="fa fa-gavel"></i>
                                </div>
                                <h3>Criminal Law</h3>
                                <p>
                                   Criminal law is a system of laws concerned with punishment of individuals who commit crimes
                                </p>
                                <a class="btn" href="criminal.html">Learn More</a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="service-item">
                                <div class="service-icon">
                                    <i class="fa fa-globe"></i>
                                </div>
                                <h3>Cyber Law</h3>
                                <p>
                                    Lorem ipsum dolor sit amet elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non
                                </p>
                                <a class="btn" href="">Learn More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Service End -->
            
            
            <!-- Feature Start -->
            
            <!-- Feature End -->
            
            
            <!-- Team Start -->
           
            <!-- Team End -->


            <!-- FAQs Start -->
            
            <!-- FAQs End -->


            <!-- Testimonial Start -->
            
            <!-- Testimonial End -->


            <!-- Blog Start -->
           
            <!-- Blog End -->
            
            
           


            <!-- Footer Start -->
            <div class="footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-lg-4">
                            <div class="footer-about">
                                <h2>About Us</h2>
                                <p>
                                    There are several crime in our country and most of the people are unaware of the criminal laws under Indian Constitution. Therefore it becomes necessary to make the peoples aware of all kinds of laws put forth by our constitution against crime so that people come forward to register case against it. The project Article Search Engine is a online  system that contains all the laws of Indian Constitution so that people can come and search for the law for respective crime. The laws are categorized into different sections according to some keywords. There is also search option available for the user to get meet the lawyers and know about the particular articles or cases.

							   </p>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-8">
                            <div class="row">
                        <div class="col-md-6 col-lg-4">
                            <div class="footer-link">
                                <h2>Services Areas</h2>
                                <a href="civil.html">Civil Law</a>
                                <a href="family.html">Family Law</a>
                                <a href="business.html">Business Law</a>
                                <a href="education.html">Education Law</a>
                                <a href="criminal.html">Criminal Law</a>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="footer-link">
                                <h2>Useful Pages</h2>
                                <a href="">About Us</a>
                                <a href="">Practices</a>
                                <a href="">Attorneys</a>
                                <a href="">Case Studies</a>
                                <a href="">FAQs</a>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="footer-contact">
                                <h2>Get In Touch</h2>
                                <p><i class="fa fa-map-marker-alt"></i>Gauhati High Court, Guwahati</p>
                                <p><i class="fa fa-phone-alt"></i>+917002421776</p>
                                <p><i class="fa fa-envelope"></i>gauhatihighcourt@gmail.com</p>
                                <div class="footer-social">
                                    <a href=""><i class="fab fa-twitter"></i></a>
                                    <a href=""><i class="fab fa-facebook-f"></i></a>
                                    <a href=""><i class="fab fa-youtube"></i></a>
                                    <a href=""><i class="fab fa-instagram"></i></a>
                                    <a href=""><i class="fab fa-linkedin-in"></i></a>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div class="container footer-menu">
                    <div class="f-menu">
                        <a href="">Terms of use</a>
                        <a href="">Privacy policy</a>
                        <a href="">Cookies</a>
                        <a href="">Help</a>
                        <a href="">FQAs</a>
                    </div>
                </div>
                <div class="container copyright">
                    <div class="row">
                        <div class="col-md-6">
                            <p>&copy; <a href="https://htmlcodex.com/law-firm-website-template">Major Project</a>, All Right Reserved.</p>
                        </div>
                        <div class="col-md-6">
                            <p>Designed By <a href="https://htmlcodex.com"></a></p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
            
            <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
        </div>

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/isotope/isotope.pkgd.min.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
    </body>
</html>

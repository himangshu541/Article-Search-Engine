<!DOCTYPE html> 
<html> 
	<head>
		<title>Search Engine in PHP</title> 
	</head>
	
<body bgcolor="gray">
	
	<form action="insert_site.php" method="post" enctype="multipart/form-data"> 
		
		<table bgcolor="orange" width="500" border="2" cellspacing="2" align="center">
			
			<tr>
				<td colspan="5" align="center"><h2>Inserting new CRPC:</h2></td>
			</tr>
			<tr>
				<td align="right"><b>CRPC Title:</b></td>
				<td><input type="text" name="title" /></td>
			</tr>
			
			<tr>
				<td align="right"><b>CRPC Link:</b></td>
				<td><input type="text" name="link" /></td>
			</tr>
			
			<tr>
				<td align="right"><b>Keywords:</b></td>
				<td><input type="text" name="keywords" /></td>
			</tr>
			
			<tr>
				<td align="right"><b>CRPC Description:</b></td>
				<td><textarea cols="18" rows="8" name="desc"></textarea></td>
			</tr>
			
		
			
			<tr>
				<td align="center" colspan="5"><input type="submit" name="submit" value="Add Article Now"/></td>
			</tr>

		
		
		</table>
	
	
	</form>

</body>
</html>
<?php 
	mysql_connect("localhost","root","");
	mysql_select_db("article");
	
	
	if(isset($_POST['submit'])){
	
		 $title = $_POST['title'];
		 $link = $_POST['link'];
		 $keywords = $_POST['keywords'];
		 $desc = $_POST['desc'];
		 
	
		
		if($title=='' OR $link=='' OR $keywords=='' OR $desc==''){
		
		echo "<script>alert('please fill all the fields!')</script>";
		
		exit();
		}
		else {
		
		$insert_query = "insert into sites (title,link,keywords,desc,) values ('$title','$link','$keywords','$desc')";
		
		
	
		if(mysql_query($insert_query)){
		
		echo "<script>alert('Data inserted into table')</script>";
		
		
		}
		
		}
	
	}


?>





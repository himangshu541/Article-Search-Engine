<?php
if ($_GET['id']){
    $id = $_GET['id'];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "article";


    $conn = new mysqli($servername, $username, $password,$dbname);

    if(!$conn)
    {
        die("connection failed:".mysqli_connect_error());
    }


    $query="SELECT * FROM `crpc` WHERE `no`='$id'";

    $results = mysqli_query($conn,$query);

    $result = mysqli_fetch_array($results);

    $query2 = "DELETE FROM `crpc` WHERE `no`='$id'";

    if (mysqli_query($conn,$query2)){
        unlink($result['content']);;
    }
}
header("location:crpcview.php");

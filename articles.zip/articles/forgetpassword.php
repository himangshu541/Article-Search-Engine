<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "article";


$conn = new mysqli($servername, $username, $password,$dbname);

if(!$conn)
{
    die("connection failed:".mysqli_connect_error());
}

if(isset($_POST['reset'])){

    $as = $_POST['answer'];
    $pwd = $_POST['password'];
    $sql = "SELECT * FROM `admin` WHERE `Answer`='$as'";
    $result = $conn->query($sql);

    if (mysqli_num_rows($result)>0){
        $results = mysqli_fetch_array($result);
        $sql3 = "UPDATE `admin` SET `password`='$pwd' WHERE 1";
        $results3 = $conn->query($sql3);

        header("location:index1.php");
    }
}
$sql2 = "SELECT `sq` FROM `admin` WHERE 1";
$result2s = $conn->query($sql2);
$result2 = mysqli_fetch_array($result2s);
$sq = $result2['sq'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Article Search Engine</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Law Firm Website Template" name="keywords">
    <meta content="Law Firm Website Template" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@1,600;1,700;1,800&family=Roboto:wght@400;500&display=swap" rel="stylesheet">

    <!-- CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="wrapper">
    <!-- Top Bar Start -->
    <div class="top-bar">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3">
                    <div class="logo">
                        <a href="index.php">
                            <h1>Article</h1>
                            <!-- <img src="img/logo.jpg" alt="Logo"> -->
                        </a>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="top-bar-right">
                        <div class="text">
                            <h2>10:00 - 17:00</h2>
                            <p>Opening Hour Mon - Fri</p>
                        </div>
                        <div class="text">
                            <h2>+918473007781</h2>
                            <p>Call Us</p>
                        </div>
                        <<?php

                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "article";
                        $conn = new mysqli($servername, $username, $password,$dbname);
                        if(!$conn)
                        {
                            die("connection failed:".mysqli_connect_error());
                        }

                        $socialQuery = "SELECT * FROM `social` WHERE 1";
                        $socialResults = $conn->query($socialQuery);
                        $socialResult = mysqli_fetch_array($socialResults);
                        ?>

                        <div class="social">
                            <a href="<?=$socialResult['twitter']?>"><i class="fab fa-twitter"></i></a>
                            <a href="<?=$socialResult['facebook']?>"><i class="fab fa-facebook-f"></i></a>
                            <a href="<?=$socialResult['linkedin']?>"><i class="fab fa-linkedin-in"></i></a>
                            <a href="<?=$socialResult['insta']?>"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Top Bar End -->

    <!-- Nav Bar Start -->
    <div class="nav-bar">
        <div class="container-fluid">
            <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                <a href="#" class="navbar-brand">MENU</a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <div class="navbar-nav mr-auto">
                        <a href="index.php" class="nav-item nav-link active">Home</a>
                        <a href="about.html" class="nav-item nav-link">About</a>
                        <a href="test.php" class="nav-item nav-link">Sign Up</a>

                    </div>
                    <div class="ml-auto">
                        <a class="btn" href="admin.php">Sign Up</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Nav Bar End -->


    <!-- Carousel Start -->

    <head>

    </head>


    <div><br><h1 align="center">ADMINISTRATOR RESET PASSWORD</h1>
    </div>

    <br><br><br><br><br>
    <div  align="center" >
        <center>
            <br>
            <table width="200" border="0" align="center">
                <form method="post"  onSubmit="return vali()">
                    <tr><td colspan="2">

                    <tr>
                        <td width="81"><?=$sq?></td>
                        <td width="103"><label>
                                <input name="answer" type="text" id="answer" onChange="return nam()">
                            </label></td>
                    </tr>
                    <tr>
                        <td>New Password:</td>
                        <td><input name="password" type="password" id="password" onChange="return pass()"></td>
                    </tr>



                    <tr>
                        <td colspan="2" align="center"><label>
                                <input name="reset" type="submit" id="sub" value="reset">
                            </label></td>

                </form>


                <tr>
            </table>
            </fieldset></center>
    </div>









    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>
</html>

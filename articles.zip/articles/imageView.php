<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "article";


$conn = new mysqli($servername, $username, $password,$dbname);

if(!$conn)
{
    die("connection failed:".mysqli_connect_error());
}


if(isset($_GET['id'])) {
    $sql = "SELECT `image` FROM `lawyer` WHERE id=". $_GET['id'];
    $result = mysqli_query($conn, $sql) or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysqli_error($conn));
    $row = mysqli_fetch_array($result);
    header("Content-type: jpg");
    echo $row["image"];
}
mysqli_close($conn);
?>